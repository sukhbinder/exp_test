from django.apps import AppConfig


class ExpConfig(AppConfig):
    name = 'exp'
