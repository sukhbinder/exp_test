from django.contrib import admin

# Register your models here.
from exp.models import Expense

admin.site.register(Expense)
